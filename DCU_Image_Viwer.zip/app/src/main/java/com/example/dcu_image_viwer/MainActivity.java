package com.example.dcu_image_viwer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final String FILENAME = "example.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE);
        } else {

            accessExternalStorage();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                accessExternalStorage();
            } else {

                Toast.makeText(this, "내부 저장소 쓰기 권한을 허용해야 합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void accessExternalStorage() {

        File externalStorageDirectory = Environment.getExternalStorageDirectory();


        File[] files = externalStorageDirectory.listFiles();


        if (files != null && files.length > 0) {

            String firstFilePath = files[0].getAbsolutePath();


            Toast.makeText(this, "첫 번째 파일 경로: " + firstFilePath, Toast.LENGTH_SHORT).show();
        } else {

            Toast.makeText(this, "외부 저장소에 파일이 없습니다.", Toast.LENGTH_SHORT).show();
        }
    }
}